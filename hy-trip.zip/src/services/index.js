export * from "./modules/home";
export * from "./modules/detail";
export * from "./modules/search";
export * from "./modules/order";
export * from "./modules/favor";
export * from "./modules/city";
//7.这里导出所有的函数，方便别的地方导入只需要导入该文件就可以
//8在store