// const baseURL = "http://localhost:1888/api"
const baseURL = "http://123.207.32.32:1888/api";
//超时时间
const TIMEOUT = 5000;
//2.这里放这请求网络得函数，自己封装好  
export { baseURL, TIMEOUT };
