<template>
  <div class="favor">
    <h2>favor</h2>
  </div>
</template>

<script setup>

</script>

<style lang="less" scoped>

</style>
