<template>
  <div class="order">
    <h2>order</h2>
  </div>
</template>

<script setup>

</script>

<style lang="less" scoped>

</style>
